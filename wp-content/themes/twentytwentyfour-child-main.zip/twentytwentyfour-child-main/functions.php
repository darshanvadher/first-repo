<?php

// enqueue parent styles

function ns_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );

        // Custom Js File
        wp_enqueue_script('cars-js', 
            get_stylesheet_directory_uri() . '/cars.js', 
            array('jquery'), 
            null, 
            true 
        );

        wp_localize_script('cars-js', 'cars', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cars_nonce')
        ));

    wp_enqueue_style( 'parent-style', get_stylesheet_directory_uri() . '/cars.js' );

}

add_action( 'wp_enqueue_scripts', 'ns_enqueue_styles' );

add_action('wp_ajax_test_a', 'test_a_Func' );
add_action('wp_ajax_nopriv_test_a', 'test_a_Func' );

function test_a_Func(){
    wp_send_json_success( 'It works' );
}