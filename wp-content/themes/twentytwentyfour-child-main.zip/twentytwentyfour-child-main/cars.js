jQuery(document).ready(function($) {

    alert('ready');

    jQuery.ajax({
        type: 'post',
        url: cars.ajax_url,
        data: {
                action: 'test_a',
                l_id: 1,
            },
        success: function(msg){
            console.log(msg);
        }
    });
});
